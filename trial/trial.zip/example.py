
start=0;
stop=100;

while  stop or start < stop:
     print stop;
