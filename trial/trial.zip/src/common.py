import sys
import os

def input_keyword():
	global keyword
	keyword = raw_input ("Please Enter keyword:")
	return keyword

def get_keyword():
	return keyword

